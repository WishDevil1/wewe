import React from 'react'

const GetQuote = () => {
  return (
    <div>GetQuote</div>
  )
}

export default GetQuote