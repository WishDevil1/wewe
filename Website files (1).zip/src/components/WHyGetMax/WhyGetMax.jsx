import React from 'react'

const WhyGetMax = () => {
  return (
    <div>WhyGetMax</div>
  )
}

export default WhyGetMax