import React from 'react'

const PowerPages = () => {
  return (
    <div>PowerPages</div>
  )
}

export default PowerPages