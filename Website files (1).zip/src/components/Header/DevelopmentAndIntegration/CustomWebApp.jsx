import React from 'react'

const CustomWebApp = () => {
  return (
    <div>CustomWebApp</div>
  )
}

export default CustomWebApp