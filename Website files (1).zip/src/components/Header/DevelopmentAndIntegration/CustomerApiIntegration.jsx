import React from 'react'

const CustomerApiIntegration = () => {
  return (
    <div>CustomerApiIntegration</div>
  )
}

export default CustomerApiIntegration