import React from 'react'

const PowerApp = () => {
  return (
    <div>PowerApp</div>
  )
}

export default PowerApp