import React from 'react'

const MicrosoftTeams = () => {
  return (
    <div>MicrosoftTeams</div>
  )
}

export default MicrosoftTeams