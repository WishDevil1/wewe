import React from 'react'

const Dataverse = () => {
  return (
    <div>Dataverse</div>
  )
}

export default Dataverse