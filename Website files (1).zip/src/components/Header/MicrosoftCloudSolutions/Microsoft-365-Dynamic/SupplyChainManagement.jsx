import React from 'react'

const SupplyChainManagement = () => {
  return (
    <div>SupplyChainManagement</div>
  )
}

export default SupplyChainManagement