import React from 'react'

const SalesAndMarketing = () => {
  return (
    <div>SalesAndMarketing</div>
  )
}

export default SalesAndMarketing