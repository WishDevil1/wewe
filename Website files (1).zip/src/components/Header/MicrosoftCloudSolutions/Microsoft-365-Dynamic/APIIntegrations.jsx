import React from 'react'

const APIIntegrations = () => {
  return (
    <div>APIIntegrations</div>
  )
}

export default APIIntegrations