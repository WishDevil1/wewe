import React from 'react'

const BusinessCentral = () => {
  return (
    <div>BusinessCentral</div>
  )
}

export default BusinessCentral