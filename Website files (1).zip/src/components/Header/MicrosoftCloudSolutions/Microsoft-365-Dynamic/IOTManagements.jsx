import React from 'react'

const IOTManagement = () => {
  return (
    <div>IOTManagement</div>
  )
}

export default IOTManagement