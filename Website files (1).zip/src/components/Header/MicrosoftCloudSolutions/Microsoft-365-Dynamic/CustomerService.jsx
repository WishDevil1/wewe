import React from 'react'

const CustomerService = () => {
  return (
    <div>CustomerService</div>
  )
}

export default CustomerService