import React from 'react'

const ServerToCloud = () => {
  return (
    <div>ServerToCloud</div>
  )
}

export default ServerToCloud