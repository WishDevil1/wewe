import React from 'react'

const ServerToServer = () => {
  return (
    <div>ServerToServer</div>
  )
}

export default ServerToServer