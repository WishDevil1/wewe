import React from 'react'

const CloudToCloud = () => {
  return (
    <div>CloudToCloud</div>
  )
}

export default CloudToCloud