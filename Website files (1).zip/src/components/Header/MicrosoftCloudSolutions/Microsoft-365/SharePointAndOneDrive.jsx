import React from 'react'

const SharePointAndOneDrive = () => {
  return (
    <div>SharePointAndOneDrive</div>
  )
}

export default SharePointAndOneDrive