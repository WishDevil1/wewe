import React from 'react'

const MicrosoftIntune = () => {
  return (
    <div>MicrosoftIntune</div>
  )
}

export default MicrosoftIntune