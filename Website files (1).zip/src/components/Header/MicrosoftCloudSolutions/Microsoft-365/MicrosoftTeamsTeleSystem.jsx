import React from 'react'

const MicrosoftTeamsTeleSystem = () => {
  return (
    <div>MicrosoftTeamsTeleSystem</div>
  )
}

export default MicrosoftTeamsTeleSystem