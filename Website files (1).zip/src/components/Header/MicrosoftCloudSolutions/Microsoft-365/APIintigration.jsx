import React from 'react'

const APIintigration = () => {
  return (
    <div>APIintigration</div>
  )
}

export default APIintigration