import React from 'react'

const PowerAutomation = () => {
  return (
    <div>PowerAutomation</div>
  )
}

export default PowerAutomation