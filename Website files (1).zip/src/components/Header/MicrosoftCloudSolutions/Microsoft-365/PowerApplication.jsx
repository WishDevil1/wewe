import React from 'react'

const PowerApplication = () => {
  return (
    <div>PowerApplication</div>
  )
}

export default PowerApplication