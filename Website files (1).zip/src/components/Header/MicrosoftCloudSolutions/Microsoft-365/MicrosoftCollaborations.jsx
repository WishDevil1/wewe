import React from 'react'

const MicrosoftCollaborations = () => {
  return (
    <div>MicrosoftCollaborations</div>
  )
}

export default MicrosoftCollaborations