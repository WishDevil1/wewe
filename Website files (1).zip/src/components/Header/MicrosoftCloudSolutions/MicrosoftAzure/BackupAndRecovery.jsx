import React from 'react'

const BackupAndRecovery = () => {
  return (
    <div>BackupAndRecovery</div>
  )
}

export default BackupAndRecovery