import React from 'react'

const AzureId = () => {
  return (
    <div>AzureId</div>
  )
}

export default AzureId