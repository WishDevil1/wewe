import React from 'react'

const AzureDevopsService = () => {
  return (
    <div>AzureDevopsService</div>
  )
}

export default AzureDevopsService