import React from 'react'

const AzureAIService = () => {
  return (
    <div>AzureAIService</div>
  )
}

export default AzureAIService