import React from 'react'

const StorageAndBackup = () => {
  return (
    <div>StorageAndBackup</div>
  )
}

export default StorageAndBackup