import React from 'react'

const LogicApps = () => {
  return (
    <div>LogicApps</div>
  )
}

export default LogicApps