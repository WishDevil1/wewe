import React from 'react'

const AzureCognetiveService = () => {
  return (
    <div>AzureCognetiveService</div>
  )
}

export default AzureCognetiveService