import React from 'react'

const AzureVirtualWorld = () => {
  return (
    <div>AzureVartualWorld</div>
  )
}

export default AzureVirtualWorld