import React from "react";

const ApplicationsAndAPIintegrations = () => {
  return <div>ApplicationsAndAPIintegrations</div>;
};

export default ApplicationsAndAPIintegrations;
