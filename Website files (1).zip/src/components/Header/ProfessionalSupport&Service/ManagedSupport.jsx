import React from 'react'

const ManagedSupport = () => {
  return (
    <div>ManagedSupport</div>
  )
}

export default ManagedSupport