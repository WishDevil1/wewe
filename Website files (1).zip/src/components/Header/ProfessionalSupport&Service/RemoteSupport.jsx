import React from 'react'

const RemoteSupport = () => {
  return (
    <div>RemoteSupport</div>
  )
}

export default RemoteSupport