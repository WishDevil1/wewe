import React from 'react'

const StoCMigration = () => {
  return (
    <div>StoCMigration</div>
  )
}

export default StoCMigration