import React from 'react'

const StoSMigration = () => {
  return (
    <div>StoSMigration</div>
  )
}

export default StoSMigration