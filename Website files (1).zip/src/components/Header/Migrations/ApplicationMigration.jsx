import React from 'react'

const ApplicationMigration = () => {
  return (
    <div>ApplicationMigration</div>
  )
}

export default ApplicationMigration