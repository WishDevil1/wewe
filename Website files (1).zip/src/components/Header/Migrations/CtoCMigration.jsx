import React from 'react'

const CtoCMigration = () => {
  return (
    <div>CtoCMigration</div>
  )
}

export default CtoCMigration