import React from 'react'

const WebsiteMigration = () => {
  return (
    <div>WebsiteMigration</div>
  )
}

export default WebsiteMigration