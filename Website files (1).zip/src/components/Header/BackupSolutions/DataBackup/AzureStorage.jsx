import React from 'react'

const AzureStorage = () => {
  return (
    <div>AzureStorage</div>
  )
}

export default AzureStorage