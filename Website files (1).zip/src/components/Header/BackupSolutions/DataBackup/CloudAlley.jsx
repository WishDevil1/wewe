import React from 'react'

const CloudAlley = () => {
  return (
    <div>CloudAlley</div>
  )
}

export default CloudAlley