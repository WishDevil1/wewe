import React from 'react'

const Acronis = () => {
  return (
    <div>Acronis</div>
  )
}

export default Acronis