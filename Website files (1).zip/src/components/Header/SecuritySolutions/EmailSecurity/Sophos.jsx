import React from 'react'

const Sophos = () => {
  return (
    <div>Sophos</div>
  )
}

export default Sophos