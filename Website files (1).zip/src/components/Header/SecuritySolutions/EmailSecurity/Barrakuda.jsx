import React from 'react'

const Barrakuda = () => {
  return (
    <div>Barrakuda</div>
  )
}

export default Barrakuda