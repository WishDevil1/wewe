import React from 'react'

const Barracuda = () => {
  return (
    <div>Barracuda</div>
  )
}

export default Barracuda