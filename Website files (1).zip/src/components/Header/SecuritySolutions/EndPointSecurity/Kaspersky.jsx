import React from 'react'

const Kaspersky = () => {
  return (
    <div>Kaspersky</div>
  )
}

export default Kaspersky